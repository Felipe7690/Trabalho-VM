sudo apt-get update
sudo apt-get upgrade -y


sudo apt-get install mysql-server -y

sudo systemctl start mysql
sudo systemctl enable mysql
